package com.company;

public class BadCharacteristicsSetted extends RuntimeException {
}
