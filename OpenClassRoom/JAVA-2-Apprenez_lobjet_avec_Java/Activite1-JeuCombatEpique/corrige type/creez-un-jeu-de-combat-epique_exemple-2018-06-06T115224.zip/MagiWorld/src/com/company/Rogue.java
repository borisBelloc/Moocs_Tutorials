package com.company;

public class Rogue extends Character {

    public Rogue(String name, int level, int strength, int agility, int intelligence) throws BadCharacteristicsSetted {
        super(name, level, strength, agility, intelligence);
    }

    @Override
    public void basicAttack(Character enemy) {
        int damage = agility;
        System.out.println(name +  " utilise Tir à l’Arc et inflige " + damage + " dommages.");
        enemy.inflictDamages(damage);
    }

    @Override
    public void specialAttack(Character enemy) {
        int agilityEarned = agility / 2;
        System.out.println(name +  " utilise Concentration et gagne " + agilityEarned + " en agilité.");
        agility += agilityEarned;
    }

    @Override
    public String toString() {
        return "Chut je suis le Rôdeur " + name +
                " niveau " + level +
                " je possède " + vitality + " de vitalité, " +
                strength + " de force, " +
                agility + " d'agilité et " +
                intelligence + " d'intelligence !";
    }
}
