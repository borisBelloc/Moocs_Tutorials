package com.company;

public class Warrior extends Character {

    public Warrior(String name, int level, int strength, int agility, int intelligence) throws BadCharacteristicsSetted {
        super(name, level, strength, agility, intelligence);
    }

    @Override
    public void basicAttack(Character enemy) {
        int damage = strength;
        System.out.println(name +  " utilise Coup d’Épée et inflige " + damage + " dommages.");
        enemy.inflictDamages(damage);
    }

    @Override
    public void specialAttack(Character enemy) {
        int damage = strength * 2;
        System.out.println(name +  " utilise Coup de Rage et inflige " + damage + " dommages.");
        enemy.inflictDamages(damage);
        int selfDamage = strength / 2;
        this.inflictDamages(selfDamage);
    }

    @Override
    public String toString() {
        return "Woarg je suis le Guerrier " + name +
                " niveau " + level +
                " je possède " + vitality + " de vitalité, " +
                strength + " de force, " +
                agility + " d'agilité et " +
                intelligence + " d'intelligence !";
    }
}
