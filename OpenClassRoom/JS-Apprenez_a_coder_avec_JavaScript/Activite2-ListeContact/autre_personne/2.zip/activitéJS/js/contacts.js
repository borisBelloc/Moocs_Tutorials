/*
Activité : gestion des contacts
*/

// TODO : complétez le programme

console.log('Bienvenue dans le gestionnaire de contacts');
console.log('1: lister les contacts');
console.log('2: ajouter un contact');
console.log('0: quitter');


//variable qui contient les deux premiers objets contact
let contacts = [
  {
    nom: 'Levisse',
    prenom: 'Carole'
  },
  {
    nom: 'Nelsonne',
    prenom: 'Mélodie'
  }
];



//fonction qui ajoute de nouveaux contacts selon ce qui est rentré dans le prompteur
function addContact(nom, prenom){
    let newContact = {
        nom: prompt("Entrez le nom du nouveau contact :"),
        prenom: prompt("Entrez le prénom du nouveau contact :")
    }
    contacts.push(newContact);
}




//fonction qui liste les elements d'un tableau
function elementListing (elements){ //passe en paramètre le nom de la liste en question
  elements.forEach(element => { //on donne le nom element a chaque element de la liste et on les affiche dans la console
    console.log(element);
  });
  return elements;
}




while (choix !== "0") {
  var choix = prompt("Faites votre choix :") //variable qui définit les choix écrits dans le prompteur

  switch (choix) {
  case "1":
      console.log("Voici la liste de tous vos contacts :");
      elementListing(contacts); //appelle la fonction qui liste les contacts
      break;
  case "2":
      addContact(); //appelle la fonction qui permet d'ajouter un contact via prompteur
      console.log("Le nouveau contact a été ajouté");
      break;
  }
}

console.log('Bye !')
