/* 
Activité : gestion des contacts
*/

// TODO : complétez le programme

const contacts = [
  {
    nom: 'Lévisse',
    prenom: 'Carole',
  },
  {
    nom: 'Nelsonne',
    prenom: 'Mélodie',
  },
];

function optionConsole(message) {
  return console.log(message);
}

function contactListing() {
  for (const contact of contacts) {
    optionConsole(`Nom : ${contact.nom}, prénom : ${contact.prenom}`);
  }
}

function optionInit() {
  optionConsole('\n');
  optionConsole('1 : Lister les contacts');
  optionConsole('2 : Ajouter un contact');
  optionConsole('0 : Quitter');
  optionConsole('\n');
  choixOption(Number(prompt('Choissisez une option :')));
}

function choixOption(choix) {
  switch (choix) {
    case 1:
      optionConsole('Voici la liste de vos contact');
      contactListing();
      optionInit();
      break;
    case 2:
      const nouveauNom = prompt('Entrez le nom du nouveau contact :');
      const nouveauPrenom = prompt('Entrez le prénom du nouveau contact :');
      const nouveauContact = {
        nom: nouveauNom,
        prenom: nouveauPrenom,
      };
      contacts.push(nouveauContact);
      optionConsole('Le nouveau contact à été ajouté');
      contactListing();
      optionInit();
      break;
    case 0:
      optionConsole('Vous avez quitté le programme');
      break;
    default:
      optionConsole("Ce choix n'est pas valide");
      optionInit();
  }
}

optionInit();
